# Continuous capsule

Fleet's canonical, dependency-free ESM geometry for the measured SwiftUI
continuous capsule. It runs in browsers and Node without React or a DOM.
This private package is not published to a registry.

```js
import { createCapsuleGeometry } from '@fleet/continuous-capsule';

const geometry = createCapsuleGeometry({ width: 214, height: 30 });
// { surfacePath, focusPath, inset } or null for an unsupported size
```

The control box includes the border. Defaults are a 1 px border, 4 px clear
focus gap, and 2 px focus stroke. Paint the paths with those widths and translate
both by `(inset, inset)`. Keep the SVG coordinate system equal to the actual
control size. Use a CSS capsule and native focus outline when the result is null.
Finite positive dimensions are required; the inset path's width/height must be
at least 1.6. Border width and gap may be zero; focus width must be positive.

The [integration guide](../../guides/continuous-capsules.md) defines the shared
workflow, rendering, and verification rules. For React, follow its linked
[adapter reference](../../guides/continuous-capsules-react.md).
Memoization belongs to the adapter; this core has no global cache or UI state.

## Ownership and provenance

Make geometry changes here first. Subvocab's original demo is historical
provenance, not an upstream dependency. This package contains every source,
fixture, and tool needed to reproduce its tests from a Fleet checkout.

The retained fixture records public SwiftUI output from macOS 27.0, build
26A428, measured on 2026-09-24. `src/profile.js` derives the runtime profile from
the first fixture; the nine independent exports remain test inputs. See the
[research record](docs/research.md) for evidence and limits. The surface matches
that profile; our focus offset and material are not a verified native UI match.

## Check and regenerate

Use Fleet's pinned Node version. From this package directory, no install is
needed to run the geometry checks:

```sh
node --test tests/*.test.js
```

To investigate another OS implementation, run on that Mac:

```sh
swift scripts/export-native.swift > /tmp/apple-capsules-candidate.json
```

Compare the candidate with `tests/fixtures/apple-capsules.json` before adopting
it. An intentional profile update replaces the fixture, regenerates the runtime
data with `node scripts/generate-profile.mjs`, updates `profileId` in the JS and
declaration files and the provenance assertion, and reruns tests. Record the
OS/build and update the package version/research when the adopted shape changes.
Normal tests use the retained fixture and need neither macOS nor Swift.

## Consume from another repository

For a local integration, from the consuming app:

```sh
pnpm add /absolute/path/to/fleet/agent-tools/packages/continuous-capsule
```

That is a local development dependency; another machine needs the same source
available. For a portable, pinned dependency, run `pnpm pack` in this package
and install the resulting tarball in the consumer, retaining the tarball in its
chosen artifact storage. Record the Fleet commit and package version used.
The tarball contains `src/` and this README; native fixtures and Swift are only
needed in Fleet for maintenance. The authoritative full guide and research
remain in the Fleet repository, so the relative documentation links above are
for that checkout, not the installed tarball.

React, Vue, Svelte, and plain HTML adapters all import the same core. Their
styles, state handling, and framework dependencies stay with the consuming app.
