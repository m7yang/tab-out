export type CapsuleOptions = {
  width: number;
  height: number;
  borderWidth?: number;
  focusGap?: number;
  focusWidth?: number;
};

export type CapsuleGeometry = {
  surfacePath: string;
  focusPath: string;
  inset: number;
};

export declare const profileId: 'swiftui-macos-27.0-26A428';
export declare function createCapsuleGeometry(options: CapsuleOptions): CapsuleGeometry | null;
